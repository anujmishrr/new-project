export const college = {
  name: 'Budhni Devi Smarak Mahila Mahavidyalaya',
  shortName: 'BDSMM',
  hindiName: 'बुधनी देवी स्मारक महिला महाविद्यालय',
  place: 'Risiya, Bahraich, Uttar Pradesh',
  address: 'Shastri Nagar, Risiya, Bahraich, Uttar Pradesh — 271801',
  phone: 'Editable phone number',
  email: 'Editable email address',
  established: 'Established institution',
};

export const navGroups = [
  { label: 'About', items: [['The college', '/about'], ['Principal', '/principal'], ['Founder', '/founder'], ['Manager', '/manager'], ['Vision & mission', '/vision-mission']] },
  { label: 'Academics', items: [['Courses', '/courses'], ['Syllabus', '/syllabus'], ['Academic calendar', '/academic-calendar'], ['Fee structure', '/fee-structure'], ['Prospectus', '/prospectus']] },
  { label: 'Admissions', items: [['Admission guide', '/admission'], ['Admission form', '/admission-form'], ['Refund policy', '/refund-policy']] },
  { label: 'Campus life', items: [['Sports', '/sports'], ['NSS', '/nss'], ['Placement', '/placement'], ['Health & wellness', '/health']] },
  { label: 'Student support', items: [['Anti-ragging', '/anti-ragging'], ['Grievance', '/grievance'], ['Sexual harassment', '/sexual-harassment'], ['ICC', '/icc'], ['SC / ST cell', '/sc-st'], ["Women’s cell", '/womens-cell']] },
];

export const notices = [
  { id: 'notice-1', date: '06 Feb 2025', tag: 'Admissions', title: 'Admission updates will be published here', text: 'Please check this notice board for official dates, documents and application instructions.' },
  { id: 'notice-2', date: '18 Jan 2025', tag: 'Academic', title: 'Academic calendar — editable placeholder', text: 'The current academic calendar can be uploaded by the college office.' },
  { id: 'notice-3', date: '03 Dec 2024', tag: 'Campus', title: 'Student support contacts', text: 'Office contact details and committee information are being prepared for publication.' },
  { id: 'notice-4', date: '11 Nov 2024', tag: 'General', title: 'Welcome to the BDSMM digital campus', text: 'A single, dependable place for students and families to find college information.' },
];

export const programs = [
  { code: 'UG · 01', title: 'Bachelor of Arts', hindi: 'कला स्नातक', detail: 'Humanities pathways and foundational study. Subject combinations are editable by the college office.', accent: 'berry' },
  { code: 'UG · 02', title: 'Bachelor of Science', hindi: 'विज्ञान स्नातक', detail: 'Science study with a grounded, practical approach. Programme details are editable placeholders.', accent: 'teal' },
  { code: 'UG · 03', title: 'Bachelor of Commerce', hindi: 'वाणिज्य स्नातक', detail: 'Commerce foundations for the next chapter. Confirm availability and subjects with the college.', accent: 'gold' },
];

export const people = [
  { id: 'faculty-1', name: 'Faculty profile — editable', role: 'Teaching staff placeholder', department: 'Department to be confirmed', initials: 'FP' },
  { id: 'faculty-2', name: 'Faculty profile — editable', role: 'Teaching staff placeholder', department: 'Department to be confirmed', initials: 'FP' },
  { id: 'faculty-3', name: 'Faculty profile — editable', role: 'Teaching staff placeholder', department: 'Department to be confirmed', initials: 'FP' },
  { id: 'staff-1', name: 'Office team — editable', role: 'Non-teaching staff placeholder', department: 'Role to be confirmed', initials: 'OS' },
];

export const documents = [
  { id: 'doc-1', title: 'College prospectus', type: 'Prospectus', path: '/prospectus', year: 'Editable' },
  { id: 'doc-2', title: 'Academic calendar', type: 'Academic', path: '/academic-calendar', year: 'Editable' },
  { id: 'doc-3', title: 'Annual report archive', type: 'Reports', path: '/annual-reports', year: 'Editable' },
  { id: 'doc-4', title: 'Development plan', type: 'Planning', path: '/development-plan', year: 'Editable' },
  { id: 'doc-5', title: 'RTI information', type: 'Transparency', path: '/rti', year: 'Current' },
];

export const galleryItems = [
  { id: 'g-1', category: 'Campus', title: 'A place to begin', className: 'gallery-sun' },
  { id: 'g-2', category: 'Learning', title: 'Curiosity in motion', className: 'gallery-berry' },
  { id: 'g-3', category: 'Community', title: 'Together, outward', className: 'gallery-teal' },
  { id: 'g-4', category: 'Campus', title: 'Open doors', className: 'gallery-ochre' },
  { id: 'g-5', category: 'Learning', title: 'The work matters', className: 'gallery-night' },
  { id: 'g-6', category: 'Community', title: 'Many points of view', className: 'gallery-rose' },
];

export const utilityLinks = [
  ['Notices', '/notices'], ['Annual reports', '/annual-reports'], ['Development plan', '/development-plan'],
  ['RTI', '/rti'], ['Gallery', '/gallery'], ['University', '/university'], ['Contact', '/contact'],
];